create function generate_friendship_id(user1 uuid, user2 uuid) returns uuid
    language plpgsql
as
$$
BEGIN
  -- You can generate a UUID based on user1 and user2 here
  -- For example:
  RETURN MD5(user1::text || user2::text)::UUID;
END;
$$;

alter function generate_friendship_id(uuid, uuid) owner to postgres;

